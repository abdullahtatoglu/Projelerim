for(var i=100;i>5;i--)
	{
		if(i%3==0)
			{
				document.write(i+"<br>");
                console.log(i);
			}
	}
